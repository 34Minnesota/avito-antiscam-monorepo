package auth

import (
	"context"
	"sync"

	"github.com/google/uuid"

	"github.com/34Minnesota/avito-antiscam-monorepo/backend/internal/domain"
)

type MemoryRepository struct {
	mu sync.RWMutex

	sessions map[uuid.UUID]*domain.Session
}

func NewMemoryRepository() *MemoryRepository {

	return &MemoryRepository{
		sessions: make(map[uuid.UUID]*domain.Session),
	}
}

func (r *MemoryRepository) Create(
	ctx context.Context,
	session *domain.Session,
) error {

	r.mu.Lock()
	defer r.mu.Unlock()

	r.sessions[session.ID] = session

	return nil
}

func (r *MemoryRepository) GetByID(
	ctx context.Context,
	id uuid.UUID,
) (*domain.Session, error) {

	r.mu.RLock()
	defer r.mu.RUnlock()

	session, ok := r.sessions[id]

	if !ok {
		return nil, nil
	}

	return session, nil
}

func (r *MemoryRepository) Update(
	ctx context.Context,
	session *domain.Session,
) error {

	r.mu.Lock()
	defer r.mu.Unlock()

	r.sessions[session.ID] = session

	return nil
}